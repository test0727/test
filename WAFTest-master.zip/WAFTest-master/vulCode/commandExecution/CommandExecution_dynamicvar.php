<?php
$dyn_func = $_GET['dyn_func'];
$argument = $_GET['argument'];

$dyn_func($argument);
?>
