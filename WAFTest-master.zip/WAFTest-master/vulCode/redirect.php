<?php header("Location: ".$_GET['page']); ?>
